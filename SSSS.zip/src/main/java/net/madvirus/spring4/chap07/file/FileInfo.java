package net.madvirus.spring4.chap07.file;

public class FileInfo {

	private String fileId;

	public FileInfo(String fileId) {
		this.fileId = fileId;
	}

	public String getFileId() {
		return fileId;
	}

}
