package spring.aop.chap06.app;

import org.aspectj.lang.ProceedingJoinPoint;

public class Profiler {
	
	public Object trace(ProceedingJoinPoint joninPoint)throws Throwable{
		
		String signatureString= joninPoint.getSignature().toShortString();
		System.out.println(signatureString+"start");
		long start = System.currentTimeMillis();
		try {
			Object result = joninPoint.proceed();
			return result;
		}finally {
			long finish = System.currentTimeMillis();
			System.out.println(signatureString +"finish");
			System.out.println(signatureString +"start time"+(finish- start)+"ms");
		}
				
	}

}
