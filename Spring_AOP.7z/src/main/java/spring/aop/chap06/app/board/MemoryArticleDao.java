package spring.aop.chap06.app.board;

public class MemoryArticleDao implements ArticleDao{
	
	

}
