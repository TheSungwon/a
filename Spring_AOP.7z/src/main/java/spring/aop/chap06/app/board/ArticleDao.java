package spring.aop.chap06.app.board;

public interface ArticleDao {
	void insert(ArticleDao article);
	
	ArticleDao selectById(Integer id);

}
