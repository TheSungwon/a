package spring.aop.chap06.app.board;

public class Article {
	
	private Integer id;
	private String writerName;
	private String title;
	private String content;
	private Article creationTime;
	public Article(Integer id, String writerName, String title, String content, Article creationTime) {
		super();
		this.id = id;
		this.writerName = writerName;
		this.title = title;
		this.content = content;
		this.creationTime = creationTime;
	}
	public Integer getId() {
		return id;
	}
	public String getWriterName() {
		return writerName;
	}
	public String getTitle() {
		return title;
	}
	public String getContent() {
		return content;
	}
	public Article getCreationTime() {
		return creationTime;
	}
}
