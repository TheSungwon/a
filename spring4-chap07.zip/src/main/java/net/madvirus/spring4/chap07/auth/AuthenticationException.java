package net.madvirus.spring4.chap07.auth;

@SuppressWarnings("serial")
public class AuthenticationException extends RuntimeException {

}
