package net.madvirus.spring4.chap08.member;

@SuppressWarnings("serial")
public class NotMatchPasswordException extends RuntimeException {

}
