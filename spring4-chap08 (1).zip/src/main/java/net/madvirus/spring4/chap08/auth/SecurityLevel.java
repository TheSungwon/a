package net.madvirus.spring4.chap08.auth;

public enum SecurityLevel {
	HIGH, LOW
}
