package spring.di.chap2.conf;

import java.util.Arrays;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import spring.di.chap2.AuthFailLogger;
import spring.di.chap2.AuthenticationService;
import spring.di.chap2.User;
import spring.di.chap2.UserRepository;

@Configuration
public class Config {

	
	@Bean
	public User user01() {
		return new User("bkchoi","1234");
	}
	
	@Bean(name="user2")
	public User user() {
		return new User("madvirus","qwer");
	}
	
	@Bean
	public UserRepository userRepositroy() {
		UserRepository userRepo = new UserRepository();
		userRepo.setUsers(Arrays.asList(user01(),user()));
		return userRepo;
	}
	
	@Bean
	public AuthFailLogger authFailLogger() {
		AuthFailLogger logger = new AuthFailLogger();
		logger.setThreshold(2);
		return logger;
	}
	
	@Bean
	public AuthenticationService authenticationService() {
		AuthenticationService authSvc = new AuthenticationService();
		authSvc.setFailLogger(authFailLogger());
		authSvc.setUserRepository(userRepositroy());
		return authSvc;
	}
}
