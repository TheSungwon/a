package spring.di.chap2.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import spring.di.chap2.AuthenticationService;
import spring.di.chap2.PasswordChangeService;
import spring.di.chap2.conf.Config;

public class MainByJavaConfig { //ConfigŬ���� ���������� ���
	
	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(Config.class);
		

		AuthenticationService authSvc = ctx.getBean("authenticationService", AuthenticationService.class);
		authSvc.authenticate("bkchoi", "1234");
		
		
		
		PasswordChangeService pwChgSvc = ctx.getBean(PasswordChangeService.class);
		pwChgSvc.changePassword("bkchoi", "1234", "5678");
		
		
		
		ctx.close();
	}

}
