package spring.di.chap2;

@SuppressWarnings("serial")
public class UserNotFoundException extends RuntimeException {

}
