package spring.di.chap2;

@SuppressWarnings("serial")
public class AuthException extends RuntimeException {

}
