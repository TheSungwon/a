package logon;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.CommandAction;
import board.LogonDBBean;
import board.LogonDataBean;

public class LogonModifyProAction  implements CommandAction{ //ȸ���������� ó��
	
	@Override
	public String pro(HttpServletRequest req, HttpServletResponse resp) throws Throwable {
		
		req.setCharacterEncoding("euc-kr");
		
		String id = req.getParameter("id");
		
		LogonDataBean member = new LogonDataBean();
		member.setPasswd(req.getParameter("passwd"));
		member.setName(req.getParameter("name"));
		member.setEmail(req.getParameter("email"));
		member.setBlog(req.getParameter("blog"));
		member.setId(id);
		
		LogonDBBean dbPro = LogonDBBean.getInstance();
		dbPro.updateMember(member);
		
		return "/logon/modifyPro.jsp";
		
	}

}
