package logon;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.CommandAction;
import board.LogonDBBean;

public class LoginProAction implements CommandAction{ //�α��� ó��
	
	@Override
	public String pro(HttpServletRequest req, HttpServletResponse resp) throws Throwable {
		
		req.setCharacterEncoding("euc-kr");
		
		String id = req.getParameter("id");
		String passwd =req.getParameter("passwd");
		
		LogonDBBean dbPro = LogonDBBean.getInstance();
		int check = dbPro.userCheck(id, passwd);
		
		req.setAttribute("check", new Integer(check));
		req.setAttribute("id", id);
		
		return "/logon/loginPro.jsp";
				
	}
	

}
