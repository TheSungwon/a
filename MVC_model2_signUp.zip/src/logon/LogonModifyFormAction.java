package logon;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.CommandAction;
import board.LogonDBBean;
import board.LogonDataBean;

public class LogonModifyFormAction implements CommandAction	{ //ȸ������ ���� �� ó��
	
	@Override
	public String pro(HttpServletRequest req, HttpServletResponse resp) throws Throwable {
		
		String id = req.getParameter("id");
		
		LogonDBBean dbPro = LogonDBBean.getInstance();
		LogonDataBean member = dbPro.getMember(id);
		
		req.setAttribute("member", member);
		
		return "/logon/modifyForm.jsp";
	}

}
