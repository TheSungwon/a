package logon;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.CommandAction;
import board.LogonDBBean;


public class LogonDeleteProAction implements CommandAction{ //Ż��ó��
	
	@Override
	public String pro(HttpServletRequest req, HttpServletResponse resp) throws Throwable {
		
		req.setCharacterEncoding("euc-kr");
		
		String id=req.getParameter("id");
		String passwd = req.getParameter("passwd");
		
		LogonDBBean dbPro = LogonDBBean.getInstance();
		int check = dbPro.deleteMember(id, passwd);
		
		req.setAttribute("check", new Integer(check));
		
		return "/logon/deletePro.jsp";
	}

}
