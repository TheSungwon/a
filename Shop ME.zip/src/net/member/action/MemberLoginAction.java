package net.member.action;


import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.member.db.MemberDAO;

public class MemberLoginAction implements Action{
	
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		HttpSession session = req.getSession();
		ActionForward forward = new ActionForward();
		MemberDAO memberdao = new MemberDAO();
		
		String id = req.getParameter("MEMBER_ID");
		String pass = req.getParameter("MEMBER_PW");
		
		int check = memberdao.userCheck(id, pass);
		
		if(check == 1) {
			session.setAttribute("id", id);
			
			if(memberdao.isAdmin(id)) {
				forward.setRedirect(true);
				forward.setPath("./GoodList.ag");
				return forward;
				
				
			}else {
				
				forward.setRedirect(true);
				forward.setPath("./GoodList.go?item=new_item");
				return forward;
				
			}
			
		}else if(check == 0) {
			res.setContentType("text/html; checset=euc-kr");
			PrintWriter out = res.getWriter();
			
			out.println("<script>");
			out.println("alert('��й�ȣ�� ��ġ���� �ʽ��ϴ�.');");
			out.println("history.go(-1);");
			out.println("</script>");
			out.close();
			
		}else {
			
			res.setContentType("text/html; charset=euc-kr");
			PrintWriter out= res.getWriter();
			
			out.println("<script>");
			out.println("alert('���̵� �������� �ʽ��ϴ�.');");
			out.println("history.go(-1);");
			out.println("</script>");
			out.close();
		}
		
		return null;
	}

}
