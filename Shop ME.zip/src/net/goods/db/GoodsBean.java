package net.goods.db;
import java.sql.Timestamp;
public class GoodsBean {
	private int GOODS_NUM;
	private String GOODS_CATEGORY;
	private String GOODS_NAME;
	private String GOODS_CONTENT;
	private String GOODS_SIZE;
	private String GOODS_COLOR;
	private int GOODS_AMOUNT;
	private int GOODS_PRICE;
	private String GOODS_IMAGE;
	private int GOODS_BEST;
	private Timestamp GOODS_DATE;
	public int getGOODS_NUM() {
		return GOODS_NUM;
	}
	public void setGOODS_NUM(int gOODS_NUM) {
		GOODS_NUM = gOODS_NUM;
	}
	public String getGOODS_CATEGORY() {
		return GOODS_CATEGORY;
	}
	public void setGOODS_CATEGORY(String gOODS_CATEGORY) {
		GOODS_CATEGORY = gOODS_CATEGORY;
	}
	public String getGOODS_NAME() {
		return GOODS_NAME;
	}
	public void setGOODS_NAME(String gOODS_NAME) {
		GOODS_NAME = gOODS_NAME;
	}
	public String getGOODS_CONTENT() {
		return GOODS_CONTENT;
	}
	public void setGOODS_CONTENT(String gOODS_CONTENT) {
		GOODS_CONTENT = gOODS_CONTENT;
	}
	public String getGOODS_SIZE() {
		return GOODS_SIZE;
	}
	public void setGOODS_SIZE(String gOODS_SIZE) {
		GOODS_SIZE = gOODS_SIZE;
	}
	public String getGOODS_COLOR() {
		return GOODS_COLOR;
	}
	public void setGOODS_COLOR(String gOODS_COLOR) {
		GOODS_COLOR = gOODS_COLOR;
	}
	public int getGOODS_AMOUNT() {
		return GOODS_AMOUNT;
	}
	public void setGOODS_AMOUNT(int gOODS_AMOUNT) {
		GOODS_AMOUNT = gOODS_AMOUNT;
	}
	public int getGOODS_PRICE() {
		return GOODS_PRICE;
	}
	public void setGOODS_PRICE(int gOODS_PRICE) {
		GOODS_PRICE = gOODS_PRICE;
	}
	public String getGOODS_IMAGE() {
		return GOODS_IMAGE;
	}
	public void setGOODS_IMAGE(String gOODS_IMAGE) {
		GOODS_IMAGE = gOODS_IMAGE;
	}
	public int getGOODS_BEST() {
		return GOODS_BEST;
	}
	public void setGOODS_BEST(int gOODS_BEST) {
		GOODS_BEST = gOODS_BEST;
	}
	public Timestamp getGOODS_DATE() {
		return GOODS_DATE;
	}
	public void setGOODS_DATE(Timestamp gOODS_DATE) {
		GOODS_DATE = gOODS_DATE;
	}
	
	
}
